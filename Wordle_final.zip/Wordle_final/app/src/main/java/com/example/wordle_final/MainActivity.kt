package com.example.wordle_final

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class MainActivity : AppCompatActivity() {
    private val MAX_GUESSES = 3
    private var targetWord: String? = null
    private var guessesLeft = 0
   /* fun stopUserInput(): Unit {
        System.exit(0)
    }*/
  /* fun resetValuesAndDisableButton(var1: Int, var2: String, button: Button): Pair<Int, String> {
       button.isEnabled = false
       return Pair(MAX_GUESSES, targetWord.toString())
   }*/


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        guessesLeft = MAX_GUESSES
        targetWord = FourLetterWordList.randomFourLetterWord
        val targetWordText = findViewById<TextView>(R.id.target_word_text)
        targetWordText.text = "Target Word: $targetWord"
        targetWordText.visibility = TextView.INVISIBLE

        val submitButton = findViewById<Button>(R.id.submit_button)
        submitButton.setOnClickListener {
            val guessEditText = findViewById<EditText>(R.id.guess_edit_text)
            val guess = guessEditText.text.toString().toUpperCase(Locale.getDefault())
            if (guess.length != 4) {
                // show an error message
                return@setOnClickListener
            }
            val result = checkGuess(targetWord, guess)
            val resultText = findViewById<TextView>(R.id.result_text)
            resultText.text = "Result: $result"
            guessesLeft--
            if (result == "OOOO") {
                // show a message indicating the user won
                //stopUserInput()
                submitButton.isEnabled = false
                targetWordText.visibility= TextView.VISIBLE


            } else if (guessesLeft == 0) {
                // show a message indicating the user lost
                //stopUserInput()

                submitButton.isEnabled = false
                targetWordText.visibility= TextView.VISIBLE
                //guessesLeft--
            } else {
                val guessesLeftText = findViewById<TextView>(R.id.guesses_left_text)
                guessesLeftText.text = "Guesses Left: $guessesLeft"

            }
        }
    }

    private fun checkGuess(targetWord: String?, guess: String): String {
        val sb = StringBuilder()
        for (i in 0 until targetWord!!.length) {
            val targetChar = targetWord[i]
            val guessChar = guess[i]
            if (targetChar == guessChar) {
                sb.append("O")
            } else if (targetWord.contains(guessChar.toString())) {
                sb.append("+")
            } else {
                sb.append("X")
            }
        }
        return sb.toString()
    }

    object FourLetterWordList {
        private val wordList = listOf(
            "WORD",
            "FIND",
            "NAME",
            "FAST",
            "CODE",
            "TEST",
            "TIME",
            "PAGE",
            "LINE",
            "WALK"
        )
        val randomFourLetterWord: String
            get() {
                val size = wordList.size
                val randomIndex = (Math.random() * size).toInt()
                return wordList[randomIndex]
            }
    }
}
